<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        DB::statement('SET FOREIGN_KEY_CHECKS=0;');

        $this->call([

            AdminUserSeeder::class,

            HouseSeeder::class,

            ResidentSeeder::class,

            HouseResidentSeeder::class,

            PaymentTypeSeeder::class,

            PaymentSeeder::class,

            ExpenseSeeder::class,

        ]);

        DB::statement('SET FOREIGN_KEY_CHECKS=1;');
    }
}
